using Microsoft.VisualStudio.TestTools.UnitTesting;

using System;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.UI;


/* 
 * 
 * Notes
 * This has been tested on July 4th, 2019 against (OFFICE system)
 * FIREFOX 60.7.2esr (64-bit)
 * CHROME Version 75 (64-bit)
 * IE Version 11
 * 
 * Note that in the lab we must use an older version of ChromeDriver at present.  
 * 
 * C. Mark Yendt (July 2019)
 */

namespace A6Start
{
    [TestClass]
    public class KatalonAutomationExample
    {
        private static IWebDriver driver;
        private StringBuilder verificationErrors;
        private bool acceptNextAlert = true;
        private const string BROWSER = "FIREFOX";
        //private const string BROWSER = "CHROME";
        //private const string BROWSER = "IE";

        private const string DRIVER_LOCATION = @"D:\Drivers";
        private const string FIREFOX_BIN_LOCATION = @"C:\Program Files\Mozilla Firefox\firefox.exe";

        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        {
            // FIREFOX
            if (BROWSER == "FIREFOX")
            {
                FirefoxDriverService service = FirefoxDriverService.CreateDefaultService(DRIVER_LOCATION);
                // Note that the line below needs to be the full exe Name not just the path
                service.FirefoxBinaryPath = FIREFOX_BIN_LOCATION;
                driver = new FirefoxDriver(service);   // WORKS 
            }
            else if (BROWSER == "CHROME")
                driver = new ChromeDriver(DRIVER_LOCATION);  // WORKS ! 
            else if (BROWSER == "IE")
                // Internet EXPLORER (NOTE : Must add DRIVER_LOCATION to Path
                driver = new InternetExplorerDriver();  // WORKS !

        }

        [ClassCleanup]
        public static void CleanupClass()
        {
            try
            {
                //driver.Quit();// quit does not close the window
                driver.Close();
                driver.Dispose();
            }
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
        }

        [TestInitialize]
        public void InitializeTest()
        {
            verificationErrors = new StringBuilder();
        }

        [TestCleanup]
        public void CleanupTest()
        {
            Assert.AreEqual("", verificationErrors.ToString());
        }

        [TestMethod]
        public void RunAllTests()
        {

            // Put your test cases in order here

            TestLoginAdmin();
            TheCreateNewUserTest();
            TestCityDirectory("Barrie {3}");
            TestCityDirectory("Aurora {2}");
            TestCityDirectory("Beamsville {1}");
            TestCityDirectory("Bright {1}");



        }

        public void TheCreateNewUserTest()
        {
            driver.Navigate().GoToUrl("https://csunix.mohawkcollege.ca/tooltime/comp10066/A3/login.php");
            try
            {
                Assert.AreEqual("Not Logged In", driver.FindElement(By.Id("loginname")).Text);
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            driver.FindElement(By.Id("username")).Click();
            driver.FindElement(By.Id("username")).Clear();
            driver.FindElement(By.Id("username")).SendKeys("admin");
            driver.FindElement(By.Name("password")).Click();
            driver.FindElement(By.Name("password")).Clear();
            driver.FindElement(By.Name("password")).SendKeys("adminP6ss");
            driver.FindElement(By.Name("Submit")).Click();
            try
            {
                Assert.AreEqual("User: admin", driver.FindElement(By.Id("loginname")).Text);
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            driver.FindElement(By.LinkText("User Admin")).Click();
            driver.FindElement(By.Id("compid")).Click();
            driver.FindElement(By.Id("username")).Clear();
            driver.FindElement(By.Id("username")).SendKeys("ayubAli8668");
            driver.FindElement(By.Id("password")).Click();
            driver.FindElement(By.Id("password")).Clear();
            driver.FindElement(By.Id("password")).SendKeys("Ayubali8668");
            driver.FindElement(By.Name("Add New Member")).Click();
            driver.Navigate().GoToUrl("https://csunix.mohawkcollege.ca/tooltime/comp10066/A3/adminuser.php?act=delete&username=ayubali8668");
            driver.FindElement(By.LinkText("User Admin")).Click();
            driver.FindElement(By.LinkText("Logout")).Click();
        }
        public void TestLoginAdmin()
        {
            driver.Navigate().GoToUrl("https://csunix.mohawkcollege.ca/tooltime/comp10066/A3/login.php");
            driver.FindElement(By.Id("username")).Click();
            driver.FindElement(By.Id("username")).Clear();
            driver.FindElement(By.Id("username")).SendKeys("admin");
            driver.FindElement(By.Name("password")).Clear();
            driver.FindElement(By.Name("password")).SendKeys("adminP6ss");
            driver.FindElement(By.Name("Submit")).Click();
            driver.FindElement(By.Id("loginname")).Click();
            try
            {
                Assert.AreEqual("User: admin", driver.FindElement(By.Id("loginname")).Text);
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            try
            {
                Assert.AreEqual("User Admin", driver.FindElement(By.LinkText("User Admin")).Text);
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            driver.FindElement(By.LinkText("Logout")).Click();
            driver.FindElement(By.Id("loginname")).Click();
            try
            {
                Assert.AreEqual("Not Logged In", driver.FindElement(By.Id("loginname")).Text);
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
        }


        public void TestCityDirectory(string city)
        {
            string cityName = "";
            string numberOfCity = "";

            try
            {
                string[] cityArray = city.Split(' ');
                cityArray[1] = cityArray[1].Substring(1, cityArray[1].Length - 2);
                cityName = cityArray[0];
                numberOfCity = cityArray[1];
            }catch(Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            driver.Navigate().GoToUrl("https://csunix.mohawkcollege.ca/tooltime/comp10066/A3/login.php");
            driver.FindElement(By.Id("username")).Click();
            driver.FindElement(By.Id("username")).Clear();
            driver.FindElement(By.Id("username")).SendKeys("admin");
            driver.FindElement(By.Name("password")).Clear();
            driver.FindElement(By.Name("password")).SendKeys("adminP6ss");
            driver.FindElement(By.Name("Submit")).Click();
            driver.FindElement(By.LinkText("Directory")).Click();
            driver.FindElement(By.Id("city")).Click();
            new SelectElement(driver.FindElement(By.Id("city"))).SelectByText(city);
            driver.FindElement(By.Id("city")).Click();
            driver.FindElement(By.Name("submit")).Click();
            try
            {
                for(int i = 1; i<=int.Parse(numberOfCity); i++)
                {
                    string xpath = "//div[@class='listresults']/ul[@id='company_" + i + "']//li[3]";
                    IWebElement webElement = driver.FindElement(By.XPath(xpath));
                    Assert.IsTrue(webElement.Text.Contains(cityName));
                }
            }
            catch (Exception e)
            {
                verificationErrors.Append(e.Message);
            }
            driver.FindElement(By.LinkText("Logout")).Click();
        }
        private bool IsElementPresent(By by)
        {
            try
            {
                driver.FindElement(by);
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        private bool IsAlertPresent()
        {
            try
            {
                driver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private string CloseAlertAndGetItsText()
        {
            try
            {
                IAlert alert = driver.SwitchTo().Alert();
                string alertText = alert.Text;
                if (acceptNextAlert)
                {
                    alert.Accept();
                }
                else
                {
                    alert.Dismiss();
                }
                return alertText;
            }
            finally
            {
                acceptNextAlert = true;
            }
        }
    }
}

